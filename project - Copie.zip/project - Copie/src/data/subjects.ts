// src/data/subjects.ts

import { mathContent } from './content/math'; // Import du contenu mathématique
import type { SubjectContent, Chapter, CourseSection, Exercise, Quiz, Question } from './types'; // Import des types nécessaires

export type { SubjectContent, Chapter, CourseSection, Exercise, Quiz, Question }; // Export des types

// Fonction utilitaire pour récupérer le contenu basé sur le niveau
const getSubjectContent = (content: Record<string, SubjectContent>, level: string): SubjectContent => {
  return content[level] || content['middle']; // Par défaut, retourne le contenu du collège
};

// Fonction pour générer les sujets en fonction du niveau
export const getSubjects = (level: 'primary' | 'middle' | 'high'): SubjectContent[] => {
  return [
    getSubjectContent(mathContent, level),
    // Ajoutez d'autres matières ici avec leur contenu spécifique au niveau
  ].filter(Boolean); // Filtrer pour éviter les valeurs nulles ou undefined
};

// Déclaration des catégories disponibles
export const categories: Record<string, { name: string }> = {
  math: { name: 'Mathématiques' },
  science: { name: 'Sciences' },
  history: { name: 'Histoire' },
  literature: { name: 'Littérature' },
  // Ajoutez d'autres catégories ici si nécessaire
};

// Fonction pour récupérer les sujets par niveau
export const getSubjectsByLevel = (level: 'primary' | 'middle' | 'high'): Record<string, SubjectContent[]> => {
  const subjects = getSubjects(level);

  // Organiser les sujets par catégorie
  const categorizedSubjects: Record<string, SubjectContent[]> = {};
  for (const subject of subjects) {
    if (subject.category) {
      if (!categorizedSubjects[subject.category]) {
        categorizedSubjects[subject.category] = [];
      }
      categorizedSubjects[subject.category].push(subject);
    }
  }
  return categorizedSubjects;
};

// Fonction pour récupérer les sujets par catégorie
export const getSubjectsByCategory = (category: string): SubjectContent[] => {
  const allSubjects = [
    ...getSubjects('primary'),
    ...getSubjects('middle'),
    ...getSubjects('high'),
  ];

  // Filtre en ajoutant une vérification pour éviter les erreurs
  return allSubjects.filter((subject) => subject.category && subject.category === category);
};

// Export des données globales
export const subjectsData = {
  primary: getSubjects('primary'),
  middle: getSubjects('middle'),
  high: getSubjects('high'),
};

// Export des sujets pour le niveau par défaut (par exemple, 'middle')
export const subjects = getSubjects('middle'); // Niveau par défaut

