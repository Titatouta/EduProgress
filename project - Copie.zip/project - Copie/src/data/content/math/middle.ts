import type { Chapter } from '../../subjects';

export const middleContent: Chapter[] = [
  {
    id: 'algebre',
    title: 'Initiation à l\'algèbre',
    description: 'Découverte des expressions littérales et équations',
    difficulty: 'medium',
    topics: ['Expressions', 'Équations', 'Calcul littéral'],
    content: {
      course: [
        {
          id: 'expressions',
          title: 'Les expressions littérales',
          type: 'text',
          content: `Une expression littérale est une expression mathématique qui contient :
- Des nombres
- Des lettres (variables)
- Des opérations

Exemples :
- 2x + 3
- 5a - 2b
- x² + 2x + 1`
        },
        {
          id: 'equations',
          title: 'Résoudre une équation',
          type: 'example',
          content: `Pour résoudre une équation du premier degré :

1. Isoler les termes avec x d'un côté
2. Isoler les nombres de l'autre côté
3. Diviser pour trouver x

Exemple : 2x + 3 = 11
1. 2x = 11 - 3
2. 2x = 8
3. x = 4`
        }
      ],
      exercises: [
        {
          id: 'ex-equations',
          title: 'Résoudre des équations',
          difficulty: 'medium',
          questions: [
            {
              id: 'q1',
              text: 'Résoudre : 3x - 4 = 8',
              options: ['x = 3', 'x = 4', 'x = 5', 'x = 6'],
              correctAnswer: 1,
              explanation: '3x = 12 donc x = 4'
            }
          ]
        }
      ],
      quizzes: [
        {
          id: 'quiz-algebre',
          title: 'Quiz d\'algèbre',
          questions: [
            {
              id: 'q1',
              text: 'Quelle est la solution de x + 5 = 12 ?',
              options: ['5', '7', '8', '12'],
              correctAnswer: 1,
              explanation: 'x = 12 - 5 = 7'
            }
          ]
        }
      ]
    }
  }
];