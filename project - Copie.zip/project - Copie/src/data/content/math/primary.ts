import type { Chapter } from '../../subjects';

export const primaryContent: Chapter[] = [
  {
    id: 'nombres',
    title: 'Les nombres jusqu\'à 100',
    description: 'Apprendre à compter et à manipuler les nombres',
    difficulty: 'easy',
    topics: ['Dénombrement', 'Comparaison', 'Addition et soustraction'],
    content: {
      course: [
        {
          id: 'compter',
          title: 'Compter jusqu\'à 100',
          type: 'text',
          content: `Pour compter jusqu'à 100, il faut :
          
1. Connaître les chiffres de 0 à 9
2. Comprendre les dizaines (10, 20, 30...)
3. Savoir combiner dizaines et unités

Par exemple :
- 45 = 4 dizaines + 5 unités
- 72 = 7 dizaines + 2 unités`
        },
        {
          id: 'comparaison',
          title: 'Comparer les nombres',
          type: 'example',
          content: `Pour comparer deux nombres, on utilise :
- Plus grand que (>)
- Plus petit que (<)
- Égal à (=)

Exemples :
15 < 25
48 > 42
33 = 33`
        }
      ],
      exercises: [
        {
          id: 'ex-compter',
          title: 'Compter et écrire',
          difficulty: 'easy',
          questions: [
            {
              id: 'q1',
              text: 'Combien y a-t-il de billes ?',
              options: ['23', '32', '28', '35'],
              correctAnswer: 2,
              explanation: 'Il y a 28 billes : 2 dizaines et 8 unités'
            }
          ]
        }
      ],
      quizzes: [
        {
          id: 'quiz-nombres',
          title: 'Quiz sur les nombres',
          questions: [
            {
              id: 'q1',
              text: 'Quel nombre est le plus grand ?',
              options: ['45', '54', '44', '53'],
              correctAnswer: 1,
              explanation: '54 est le plus grand car 5 dizaines + 4 unités est plus grand que les autres nombres'
            }
          ]
        }
      ]
    }
  }
];