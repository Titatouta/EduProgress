import type { Chapter } from '../../subjects';

export const highContent: Chapter[] = [
  {
    id: 'fonctions',
    title: 'Étude des fonctions',
    description: 'Fonctions, dérivées et limites',
    difficulty: 'hard',
    topics: ['Fonctions', 'Dérivées', 'Limites'],
    content: {
      course: [
        {
          id: 'fonctions-base',
          title: 'Les fonctions',
          type: 'text',
          content: `Une fonction est une relation qui associe à chaque élément x d'un ensemble de départ un unique élément y.

Notations :
f : x ↦ f(x)
y = f(x)

Exemple :
f(x) = 2x + 1 associe à chaque nombre x le double de x plus 1`
        },
        {
          id: 'derivees',
          title: 'Dérivées',
          type: 'formula',
          content: `La dérivée mesure le taux de variation d'une fonction.

Formules usuelles :
- (kx)' = k
- (x²)' = 2x
- (x³)' = 3x²
- (1/x)' = -1/x²`
        }
      ],
      exercises: [
        {
          id: 'ex-derivees',
          title: 'Calcul de dérivées',
          difficulty: 'hard',
          questions: [
            {
              id: 'q1',
              text: 'Calculer la dérivée de f(x) = 3x² - 2x + 1',
              options: [
                'f\'(x) = 6x - 2',
                'f\'(x) = 3x - 2',
                'f\'(x) = 6x² - 2',
                'f\'(x) = 3x² - 2'
              ],
              correctAnswer: 0,
              explanation: "(3x²)' = 6x et (-2x)' = -2, la constante disparaît"
            }
          ]
        }
      ],
      quizzes: [
        {
          id: 'quiz-fonctions',
          title: 'Quiz sur les fonctions',
          questions: [
            {
              id: 'q1',
              text: 'Pour f(x) = x² + 1, que vaut f(2) ?',
              options: ['3', '4', '5', '6'],
              correctAnswer: 2,
              explanation: 'f(2) = 2² + 1 = 4 + 1 = 5'
            }
          ]
        }
      ]
    }
  }
];