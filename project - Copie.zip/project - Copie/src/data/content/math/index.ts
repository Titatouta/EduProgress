import { primaryContent } from './primary';
import { middleContent } from './middle';
import { highContent } from './high';
import type { SubjectContent } from '../../subjects';

export const mathContent: Record<string, SubjectContent> = {
  primary: {
    id: 'math',
    name: 'Mathématiques',
    level: 'primary',
    icon: '📐',
    color: 'bg-blue-500',
    description: 'Nombres, calculs et géométrie',
    chapters: primaryContent
  },
  middle: {
    id: 'math',
    name: 'Mathématiques',
    level: 'middle',
    icon: '📐',
    color: 'bg-blue-500',
    description: 'Algèbre, géométrie et arithmétique',
    chapters: middleContent
  },
  high: {
    id: 'math',
    name: 'Mathématiques',
    level: 'high',
    icon: '📐',
    color: 'bg-blue-500',
    description: 'Analyse, algèbre et géométrie',
    chapters: highContent
  }
};