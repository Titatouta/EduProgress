import type { SubjectContent } from './types';

export const languageSubjects: Record<string, SubjectContent> = {
  french: {
    id: 'french',
    name: 'Français',
    level: 'middle',
    icon: '📚',
    color: 'bg-purple-500',
    animation: 'https://assets9.lottiefiles.com/packages/lf20_5n8yfkac.json',
    description: 'Grammaire, conjugaison et littérature',
    category: 'languages',
    chapters: []
  },
  english: {
    id: 'english',
    name: 'Anglais',
    level: 'middle',
    icon: '🇬🇧',
    color: 'bg-indigo-500',
    animation: 'https://assets8.lottiefiles.com/packages/lf20_jtbfg2nb.json',
    description: 'Langue et culture anglophone',
    category: 'languages',
    chapters: []
  },
  german: {
    id: 'german',
    name: 'Allemand',
    level: 'middle',
    icon: '🇩🇪',
    color: 'bg-orange-500',
    animation: 'https://assets4.lottiefiles.com/packages/lf20_vcqk2nqd.json',
    description: 'Langue et culture allemande',
    category: 'languages',
    chapters: []
  },
  spanish: {
    id: 'spanish',
    name: 'Espagnol',
    level: 'middle',
    icon: '🇪🇸',
    color: 'bg-purple-500',
    animation: 'https://assets1.lottiefiles.com/packages/lf20_hxart9lz.json',
    description: 'Langue et culture hispanique',
    category: 'languages',
    chapters: []
  }
};