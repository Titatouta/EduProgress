import type { SubjectContent } from './types';

export const otherSubjects: Record<string, SubjectContent> = {
  'revisions-express': {
    id: 'revisions-express',
    name: 'Révisions express',
    level: 'middle',
    icon: '🎯',
    color: 'bg-pink-500',
    animation: 'https://assets2.lottiefiles.com/packages/lf20_jtbfg2nb.json',
    description: 'Révisions rapides des points essentiels',
    category: 'other',
    chapters: []
  }
};