export const subjectAnimations = {
  math: 'https://assets2.lottiefiles.com/packages/lf20_qp1q7mct.json',
  physics: 'https://assets5.lottiefiles.com/packages/lf20_qwgvjgkx.json',
  french: 'https://assets9.lottiefiles.com/packages/lf20_5n8yfkac.json',
  history: 'https://assets3.lottiefiles.com/packages/lf20_yxqnhjv0.json',
  geography: 'https://assets6.lottiefiles.com/packages/lf20_ksxv9zgi.json',
  english: 'https://assets8.lottiefiles.com/packages/lf20_jtbfg2nb.json',
  spanish: 'https://assets1.lottiefiles.com/packages/lf20_hxart9lz.json',
  german: 'https://assets4.lottiefiles.com/packages/lf20_vcqk2nqd.json',
  svt: 'https://assets7.lottiefiles.com/packages/lf20_osdxlbqq.json',
  civics: 'https://assets10.lottiefiles.com/packages/lf20_rqfvg6jr.json',
  'revisions-express': 'https://assets2.lottiefiles.com/packages/lf20_jtbfg2nb.json'
};