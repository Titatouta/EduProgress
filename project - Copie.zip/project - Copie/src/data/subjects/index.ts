import { categories, type CategoryId } from './categories';
import { languageSubjects } from './languages';
import { scienceSubjects } from './sciences';
import { humanitySubjects } from './humanities';
import { otherSubjects } from './other';
import type { SubjectContent } from './types';

// Combine all subjects into a single record
const allSubjects: Record<string, SubjectContent> = {
  ...languageSubjects,
  ...scienceSubjects,
  ...humanitySubjects,
  ...otherSubjects
};

// Helper function to get subjects by level
export const getSubjectsByLevel = (level: 'primary' | 'middle' | 'high') => {
  const filteredSubjects = Object.values(allSubjects).filter(subject => subject.level === level);
  
  // Group subjects by category
  const categorizedSubjects = Object.keys(categories).reduce((acc, categoryId) => {
    const categorySubjects = filteredSubjects.filter(
      subject => subject.category === categoryId
    );
    
    return {
      ...acc,
      [categoryId]: categorySubjects
    };
  }, {} as Record<CategoryId, SubjectContent[]>);

  return {
    subjects: categorizedSubjects,
    categories
  };
};

// Export everything needed
export { categories };
export { allSubjects as subjects };
export type { SubjectContent, CategoryId };