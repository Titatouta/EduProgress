import type { SubjectContent } from './types';

export const scienceSubjects: Record<string, SubjectContent> = {
  math: {
    id: 'math',
    name: 'Mathématiques',
    level: 'middle',
    icon: '📐',
    color: 'bg-blue-500',
    animation: 'https://assets2.lottiefiles.com/packages/lf20_qp1q7mct.json',
    description: 'Algèbre, géométrie et arithmétique',
    category: 'sciences',
    chapters: []
  },
  physics: {
    id: 'physics',
    name: 'Physique-chimie',
    level: 'middle',
    icon: '⚗️',
    color: 'bg-cyan-500',
    animation: 'https://assets5.lottiefiles.com/packages/lf20_qwgvjgkx.json',
    description: 'Matière, énergie et transformations',
    category: 'sciences',
    chapters: []
  },
  svt: {
    id: 'svt',
    name: 'SVT',
    level: 'middle',
    icon: '🧬',
    color: 'bg-emerald-500',
    animation: 'https://assets7.lottiefiles.com/packages/lf20_osdxlbqq.json',
    description: 'Sciences de la vie et de la Terre',
    category: 'sciences',
    chapters: []
  }
};