import type { CategoryId } from './categories';

export interface SubjectContent {
  id: string;
  name: string;
  level: 'primary' | 'middle' | 'high';
  icon: string;
  color: string;
  animation: string;
  description: string;
  category: CategoryId;
  chapters: Chapter[];
}

export interface Chapter {
  id: string;
  title: string;
  description: string;
  difficulty: 'easy' | 'medium' | 'hard';
  topics: string[];
  content: {
    course: CourseSection[];
    exercises: Exercise[];
    quizzes: Quiz[];
  };
}

export interface CourseSection {
  id: string;
  title: string;
  content: string;
  type: 'text' | 'video' | 'example' | 'formula' | 'studygram';
}

export interface Exercise {
  id: string;
  title: string;
  difficulty: 'easy' | 'medium' | 'hard';
  questions: Question[];
}

export interface Quiz {
  id: string;
  title: string;
  questions: Question[];
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}