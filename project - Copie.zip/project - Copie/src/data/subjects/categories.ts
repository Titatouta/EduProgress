export const categories = {
  languages: {
    id: 'languages',
    name: 'Langues et Lettres',
    order: 1
  },
  sciences: {
    id: 'sciences',
    name: 'Sciences',
    order: 2
  },
  humanities: {
    id: 'humanities',
    name: 'Sciences Humaines',
    order: 3
  },
  other: {
    id: 'other',
    name: 'Révisions et Méthodologie',
    order: 4
  }
} as const;

export type CategoryId = keyof typeof categories;