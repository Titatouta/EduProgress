import type { SubjectContent } from './types';

export const humanitySubjects: Record<string, SubjectContent> = {
  history: {
    id: 'history',
    name: 'Histoire',
    level: 'middle',
    icon: '🏛️',
    color: 'bg-orange-500',
    animation: 'https://assets3.lottiefiles.com/packages/lf20_yxqnhjv0.json',
    description: 'De l\'Antiquité à nos jours',
    category: 'humanities',
    chapters: []
  },
  geography: {
    id: 'geography',
    name: 'Géographie',
    level: 'middle',
    icon: '🌍',
    color: 'bg-yellow-500',
    animation: 'https://assets6.lottiefiles.com/packages/lf20_ksxv9zgi.json',
    description: 'Étude des territoires et sociétés',
    category: 'humanities',
    chapters: []
  },
  civics: {
    id: 'civics',
    name: 'Enseignement moral et civique',
    level: 'middle',
    icon: '⚖️',
    color: 'bg-amber-500',
    animation: 'https://assets10.lottiefiles.com/packages/lf20_rqfvg6jr.json',
    description: 'Citoyenneté et vie en société',
    category: 'humanities',
    chapters: []
  }
};