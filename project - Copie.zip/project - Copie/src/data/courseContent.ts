export interface CourseSection {
  id: string;
  title: string;
  content: string;
  type: 'text' | 'example' | 'formula' | 'image';
}

export interface CourseContent {
  id: string;
  subjectId: string;
  chapterId: string;
  title: string;
  sections: CourseSection[];
}

export const courseContents: Record<string, CourseContent> = {
  'math-algebra-basics': {
    id: 'math-algebra-basics',
    subjectId: 'math',
    chapterId: 'algebra-basics',
    title: 'Bases de l\'algèbre',
    sections: [
      {
        id: 'intro',
        title: 'Introduction aux expressions algébriques',
        type: 'text',
        content: `Une expression algébrique est une combinaison de nombres et de lettres reliés par des opérations mathématiques (addition, soustraction, multiplication, division).

Par exemple : 2x + 3 est une expression algébrique où :
- 2 est un coefficient
- x est une variable
- 3 est un terme constant`
      },
      {
        id: 'examples',
        title: 'Exemples d\'expressions',
        type: 'example',
        content: `Voici quelques exemples d'expressions algébriques :
1. 3x + 5
2. 2x² - 4x + 1
3. (x + 2)(x - 3)`
      },
      {
        id: 'formulas',
        title: 'Formules importantes',
        type: 'formula',
        content: `Identités remarquables :
(a + b)² = a² + 2ab + b²
(a - b)² = a² - 2ab + b²
(a + b)(a - b) = a² - b²`
      }
    ]
  },
  'french-grammar': {
    id: 'french-grammar',
    subjectId: 'french',
    chapterId: 'grammar',
    title: 'Les bases de la grammaire française',
    sections: [
      {
        id: 'intro',
        title: 'La nature des mots',
        type: 'text',
        content: `En français, chaque mot appartient à une catégorie grammaticale spécifique :
- Les noms
- Les verbes
- Les adjectifs
- Les déterminants
- Les pronoms
- Les adverbes
- Les prépositions
- Les conjonctions`
      },
      {
        id: 'examples',
        title: 'Exemples d\'analyse',
        type: 'example',
        content: `Analysons cette phrase :
"Le petit chat noir dort paisiblement."
- Le : déterminant
- petit : adjectif qualificatif
- chat : nom commun
- noir : adjectif qualificatif
- dort : verbe
- paisiblement : adverbe`
      }
    ]
  }
};