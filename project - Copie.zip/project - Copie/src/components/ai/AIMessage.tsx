import React from 'react';
import { Loader2 } from 'lucide-react';

interface AIMessageProps {
  role: 'user' | 'assistant';
  content: string;
  error?: {
    type: string;
    message: string;
  };
  isLoading?: boolean;
}

export function AIMessage({ role, content, error, isLoading }: AIMessageProps) {
  if (isLoading) {
    return (
      <div className="flex justify-start">
        <div className="bg-gray-100 rounded-lg p-3">
          <Loader2 className="animate-spin" size={20} />
        </div>
      </div>
    );
  }

  return (
    <div className={`flex ${role === 'user' ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`max-w-[80%] rounded-lg p-3 ${
          role === 'user'
            ? 'bg-indigo-600 text-white'
            : error
            ? 'bg-yellow-50 text-gray-800 border border-yellow-200'
            : 'bg-gray-100 text-gray-800'
        }`}
      >
        {content}
      </div>
    </div>
  );
}