import React from 'react';
import { AlertCircle } from 'lucide-react';

interface AIErrorMessageProps {
  message: string;
}

export function AIErrorMessage({ message }: AIErrorMessageProps) {
  return (
    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
      <div className="flex items-center gap-2">
        <AlertCircle className="text-yellow-400" size={20} />
        <p className="text-sm text-yellow-700">{message}</p>
      </div>
    </div>
  );
}