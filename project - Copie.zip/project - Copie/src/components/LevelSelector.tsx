import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import { grades, gradeCategories, Grade } from '../types/grades';

interface LevelSelectorProps {
  selectedLevel: Grade;
  onLevelChange: (level: Grade) => void;
}

export function LevelSelector({ selectedLevel, onLevelChange }: LevelSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative">
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="inline-flex items-center gap-2 px-6 py-3 bg-white rounded-xl shadow-sm text-gray-700 hover:bg-gray-50 border border-gray-100"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        <span className="text-lg font-medium">{selectedLevel.name}</span>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.2 }}
        >
          <ChevronDown size={20} />
        </motion.div>
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="absolute z-50 mt-2 w-64 bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden"
          >
            {Object.entries(gradeCategories).map(([category, label]) => (
              <div key={category} className="p-2">
                <div className="text-xs font-semibold text-gray-500 px-3 py-1">
                  {label}
                </div>
                {grades
                  .filter(grade => grade.category === category)
                  .map(grade => (
                    <motion.button
                      key={grade.id}
                      onClick={() => {
                        onLevelChange(grade);
                        setIsOpen(false);
                      }}
                      className={`w-full text-left px-4 py-2 text-sm rounded-lg ${
                        selectedLevel.id === grade.id
                          ? 'bg-primary-50 text-primary-600'
                          : 'hover:bg-gray-50'
                      }`}
                      whileHover={{ x: 4 }}
                      transition={{ duration: 0.2 }}
                    >
                      {grade.name}
                    </motion.button>
                  ))}
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}