import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Player } from '@lottiefiles/react-lottie-player';
import type { SubjectContent } from '../data/subjects';

interface SubjectCardProps {
  subject: SubjectContent;
  index?: number;
}

export function SubjectCard({ subject, index = 0 }: SubjectCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Link 
        to={`/subjects/${subject.id}`}
        className="block transform transition-all duration-300 hover:scale-105"
      >
        <motion.div 
          className="relative bg-white rounded-3xl shadow-lg overflow-hidden p-6"
          whileHover={{ y: -5 }}
          transition={{ duration: 0.2 }}
        >
          <div className="relative z-10">
            <div className="h-32 mb-4">
              {subject.animation && (
                <Player
                  autoplay
                  loop
                  src={subject.animation}
                  style={{ height: '100%', width: '100%' }}
                />
              )}
            </div>
            
            <h3 className="text-xl font-bold text-gray-800 text-center">
              {subject.name}
            </h3>
          </div>

          <div className="absolute inset-0 opacity-10">
            <div className={`absolute top-0 right-0 w-32 h-32 ${subject.color} rounded-full transform translate-x-8 -translate-y-8`} />
            <div className={`absolute bottom-0 left-0 w-24 h-24 ${subject.color} rounded-full transform -translate-x-6 translate-y-6`} />
          </div>
        </motion.div>
      </Link>
    </motion.div>
  );
}