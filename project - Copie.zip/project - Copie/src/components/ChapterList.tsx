import React from 'react';
import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';

interface Chapter {
  id: string;
  title: string;
  lessons: {
    id: string;
    title: string;
  }[];
}

interface ChapterListProps {
  chapters: Chapter[];
}

export function ChapterList({ chapters }: ChapterListProps) {
  return (
    <div className="space-y-6">
      {chapters.map((chapter, index) => (
        <motion.div
          key={chapter.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
          className="bg-white rounded-2xl shadow-md overflow-hidden"
        >
          <div className="p-4 bg-gradient-to-r from-indigo-500 to-purple-500">
            <h3 className="text-lg font-bold text-white">
              Chapitre {index + 1} - {chapter.title}
            </h3>
          </div>
          
          <div className="divide-y divide-gray-100">
            {chapter.lessons.map((lesson, lessonIndex) => (
              <motion.div
                key={lesson.id}
                whileHover={{ x: 10, backgroundColor: 'rgba(249, 250, 251, 1)' }}
                className="p-4 flex items-center justify-between cursor-pointer"
              >
                <span className="text-gray-700">{lesson.title}</span>
                <ChevronRight className="text-gray-400" size={20} />
              </motion.div>
            ))}
          </div>
        </motion.div>
      ))}
    </div>
  );
}