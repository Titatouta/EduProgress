import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen } from 'lucide-react';
import type { Quiz } from '../types';

interface QuizCardProps {
  quiz: Quiz;
}

export function QuizCard({ quiz }: QuizCardProps) {
  return (
    <Link to={`/quiz/${quiz.id}`} className="block">
      <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
        <div className="flex items-center gap-3 mb-4">
          <BookOpen className="text-indigo-600" size={24} />
          <h3 className="text-lg font-semibold">{quiz.title}</h3>
        </div>
        <p className="text-sm text-gray-600">
          {quiz.questions.length} questions
        </p>
        <button className="mt-4 w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors">
          Commencer
        </button>
      </div>
    </Link>
  );
}