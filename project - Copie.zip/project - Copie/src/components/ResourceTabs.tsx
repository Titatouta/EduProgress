import React from 'react';
import { motion } from 'framer-motion';
import { Video, Book, PenTool, Layout, FileText } from 'lucide-react';

interface ResourceTabsProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function ResourceTabs({ activeTab, onTabChange }: ResourceTabsProps) {
  const tabs = [
    { id: 'video', label: 'Vidéo', icon: Video },
    { id: 'cours', label: 'Cours', icon: Book },
    { id: 'studygram', label: 'Studygram', icon: Layout },
    { id: 'quiz', label: 'Quiz', icon: PenTool },
    { id: 'exercice', label: 'Exercice', icon: FileText },
  ];

  return (
    <div className="flex justify-center gap-4 mb-8">
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        const Icon = tab.icon;
        
        return (
          <motion.button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`relative flex flex-col items-center p-4 rounded-xl ${
              isActive ? 'text-white' : 'text-gray-500 hover:text-gray-700'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {isActive && (
              <motion.div
                layoutId="activeTab"
                className="absolute inset-0 bg-gradient-to-r from-pink-500 to-purple-500 rounded-xl"
                initial={false}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              />
            )}
            <span className="relative z-10">
              <Icon size={24} />
            </span>
            <span className="relative z-10 text-sm mt-2">{tab.label}</span>
          </motion.button>
        );
      })}
    </div>
  );
}