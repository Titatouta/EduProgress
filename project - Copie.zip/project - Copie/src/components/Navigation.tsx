import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Home, Trophy, UserCircle } from 'lucide-react';

export function Navigation() {
  return (
    <nav className="fixed bottom-0 w-full bg-white border-t border-gray-200 py-2">
      <div className="container mx-auto px-4">
        <div className="flex justify-around items-center">
          <Link to="/" className="flex flex-col items-center text-indigo-600">
            <Home size={24} />
            <span className="text-xs mt-1">Accueil</span>
          </Link>
          <Link to="/subjects" className="flex flex-col items-center text-gray-600 hover:text-indigo-600">
            <BookOpen size={24} />
            <span className="text-xs mt-1">Matières</span>
          </Link>
          <Link to="/achievements" className="flex flex-col items-center text-gray-600 hover:text-indigo-600">
            <Trophy size={24} />
            <span className="text-xs mt-1">Succès</span>
          </Link>
          <Link to="/profile" className="flex flex-col items-center text-gray-600 hover:text-indigo-600">
            <UserCircle size={24} />
            <span className="text-xs mt-1">Profil</span>
          </Link>
        </div>
      </div>
    </nav>
  );
}