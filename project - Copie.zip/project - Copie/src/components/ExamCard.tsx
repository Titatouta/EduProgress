import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, BarChart } from 'lucide-react';
import type { Exam } from '../services/examService';

interface ExamCardProps {
  exam: Exam;
}

export function ExamCard({ exam }: ExamCardProps) {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return 'text-green-600';
      case 'medium':
        return 'text-yellow-600';
      case 'hard':
        return 'text-red-600';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-lg font-semibold mb-3">{exam.title}</h3>
      
      <div className="flex items-center gap-4 mb-4">
        <div className="flex items-center gap-2">
          <Clock size={16} className="text-gray-500" />
          <span className="text-sm text-gray-600">{exam.duration} min</span>
        </div>
        <div className="flex items-center gap-2">
          <BarChart size={16} className="text-gray-500" />
          <span className={`text-sm font-medium ${getDifficultyColor(exam.difficulty)}`}>
            {exam.difficulty.charAt(0).toUpperCase() + exam.difficulty.slice(1)}
          </span>
        </div>
      </div>

      <div className="mb-4">
        <div className="text-sm text-gray-600 mb-1">Score minimum requis</div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-indigo-600 rounded-full h-2"
            style={{ width: `${exam.passingScore}%` }}
          />
        </div>
        <div className="text-sm text-gray-600 mt-1">{exam.passingScore}%</div>
      </div>

      <Link
        to={`/exam/${exam.id}`}
        className="block w-full text-center bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors"
      >
        Commencer l'examen
      </Link>
    </div>
  );
}