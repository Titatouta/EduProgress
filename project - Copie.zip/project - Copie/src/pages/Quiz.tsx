import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { CheckCircle2, XCircle } from 'lucide-react';
import ApiService, { CommonLitQuestion } from '../services/api';

export function Quiz() {
  const { textId } = useParams();
  const [questions, setQuestions] = useState<CommonLitQuestion[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    const fetchQuestions = async () => {
      if (textId) {
        const api = ApiService.getInstance();
        const fetchedQuestions = await api.getQuestions(textId);
        setQuestions(fetchedQuestions);
      }
    };
    fetchQuestions();
  }, [textId]);

  const handleAnswerSelect = (index: number) => {
    if (selectedAnswer === null) {
      setSelectedAnswer(index);
      if (index === questions[currentQuestion].correctAnswer) {
        setScore(score + 1);
      }
      setShowExplanation(true);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    }
  };

  if (questions.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  const question = questions[currentQuestion];

  return (
    <div className="min-h-screen bg-gray-50 pb-20 px-4">
      <div className="container mx-auto max-w-3xl py-8">
        <div className="bg-white rounded-lg shadow-md p-8">
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <span className="text-sm text-gray-500">
                Question {currentQuestion + 1} sur {questions.length}
              </span>
              <span className="text-sm font-medium text-indigo-600">
                Score: {score}/{questions.length}
              </span>
            </div>
            <h2 className="text-xl font-semibold mb-6">{question.question}</h2>
            <div className="space-y-4">
              {question.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(index)}
                  disabled={selectedAnswer !== null}
                  className={`w-full text-left p-4 rounded-lg border transition-colors ${
                    selectedAnswer === null
                      ? 'hover:bg-gray-50 border-gray-200'
                      : selectedAnswer === index
                      ? index === question.correctAnswer
                        ? 'bg-green-50 border-green-500'
                        : 'bg-red-50 border-red-500'
                      : index === question.correctAnswer
                      ? 'bg-green-50 border-green-500'
                      : 'border-gray-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {selectedAnswer !== null && index === question.correctAnswer && (
                      <CheckCircle2 className="text-green-500" size={20} />
                    )}
                    {selectedAnswer === index && index !== question.correctAnswer && (
                      <XCircle className="text-red-500" size={20} />
                    )}
                    <span>{option}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {showExplanation && (
            <div className="mb-8 p-4 bg-gray-50 rounded-lg">
              <h3 className="font-semibold mb-2">Explication</h3>
              <p className="text-gray-600">{question.explanation}</p>
            </div>
          )}

          {selectedAnswer !== null && currentQuestion < questions.length - 1 && (
            <button
              onClick={handleNextQuestion}
              className="w-full bg-indigo-600 text-white py-3 px-4 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Question suivante
            </button>
          )}
        </div>
      </div>
    </div>
  );
}