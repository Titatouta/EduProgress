import React from 'react';
import { Trophy, Star, Target, Award } from 'lucide-react';

const achievements = [
  {
    id: 'streak-7',
    title: 'Série de 7 jours',
    description: 'Connecté 7 jours consécutifs',
    icon: Trophy,
    completed: true
  },
  {
    id: 'perfect-quiz',
    title: 'Quiz parfait',
    description: '100% de bonnes réponses',
    icon: Star,
    completed: true
  },
  {
    id: 'first-course',
    title: 'Premier cours',
    description: 'Terminer votre premier cours',
    icon: Target,
    completed: false
  },
  {
    id: 'master',
    title: 'Maître',
    description: 'Obtenir 1000 points',
    icon: Award,
    completed: false
  }
];

export function Achievements() {
  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold text-gray-900">Succès</h1>
          <p className="text-gray-600 mt-2">Vos réalisations et badges</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-4">
          {achievements.map((achievement) => (
            <div
              key={achievement.id}
              className={`bg-white rounded-lg shadow-md p-4 flex items-center gap-4 ${
                achievement.completed ? 'border-l-4 border-green-500' : ''
              }`}
            >
              <achievement.icon
                className={`${
                  achievement.completed ? 'text-green-500' : 'text-gray-400'
                }`}
                size={24}
              />
              <div>
                <h3 className="font-semibold">{achievement.title}</h3>
                <p className="text-sm text-gray-600">{achievement.description}</p>
              </div>
              {achievement.completed && (
                <span className="ml-auto text-green-500 text-sm font-medium">
                  Complété
                </span>
              )}
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}