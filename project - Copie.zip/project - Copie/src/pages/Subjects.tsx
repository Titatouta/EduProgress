// src/pages/Subjects.tsx

import React, { useState } from 'react';
import { SubjectCard } from '../components/SubjectCard';
import { LevelSelector } from '../components/LevelSelector';
import { getSubjectsByLevel, categories } from '../data/subjects';
import { grades } from '../types/grades';
import { PageContainer } from '../components/layout/PageContainer';
import { ContentContainer } from '../components/layout/ContentContainer';
import { FadeIn } from '../components/animations/FadeIn';

export function Subjects() {
  const [selectedLevel, setSelectedLevel] = useState(() =>
    grades.find((g) => g.id === '3e') || grades[0] // Fallback sur le premier grade si '3e' n'est pas trouvé
  );

  // Récupérer les sujets par niveau
  const subjectsByLevel = getSubjectsByLevel(selectedLevel.category || 'middle');

  return (
    <PageContainer>
      <div className="min-h-screen bg-background">
        <ContentContainer>
          <div className="py-12">
            <div className="flex items-center justify-between mb-12">
              <FadeIn>
                <h1 className="text-4xl font-bold text-gray-900">
                  Matières de {selectedLevel.name}
                </h1>
              </FadeIn>

              <FadeIn delay={0.2}>
                <LevelSelector
                  selectedLevel={selectedLevel}
                  onLevelChange={setSelectedLevel}
                />
              </FadeIn>
            </div>

            <div className="space-y-16">
              {Object.entries(categories).map(([categoryId, category]) => {
                const categorySubjects = subjectsByLevel[categoryId] || [];

                if (categorySubjects.length === 0) {
                  return null;
                }

                return (
                  <section key={categoryId}>
                    <FadeIn>
                      <h2 className="text-2xl font-bold text-gray-900 mb-8">
                        {category.name}
                      </h2>
                    </FadeIn>

                    <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                      {categorySubjects.map((subject, index) => (
                        <SubjectCard
                          key={subject.id || index}
                          subject={subject}
                          index={index}
                        />
                      ))}
                    </div>
                  </section>
                );
              })}
            </div>
          </div>
        </ContentContainer>
      </div>
    </PageContainer>
  );
}
