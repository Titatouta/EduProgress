import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Clock, AlertCircle } from 'lucide-react';
import type { Exam } from '../services/examService';
import ExamService from '../services/examService';

export function Exam() {
  const { examId } = useParams();
  const navigate = useNavigate();
  const [exam, setExam] = useState<Exam | null>(null);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const fetchExam = async () => {
      if (examId) {
        const examService = ExamService.getInstance();
        const exams = await examService.getExams('math'); // Replace with actual subject ID
        const foundExam = exams.find(e => e.id === examId);
        if (foundExam) {
          setExam(foundExam);
          setTimeLeft(foundExam.duration * 60); // Convert minutes to seconds
        }
      }
    };
    fetchExam();
  }, [examId]);

  useEffect(() => {
    if (started && timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft(time => {
          if (time <= 1) {
            clearInterval(timer);
            // Handle exam submission when time is up
            return 0;
          }
          return time - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [started, timeLeft]);

  if (!exam) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleStart = () => {
    setStarted(true);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold text-gray-900">{exam.title}</h1>
          {started && (
            <div className="flex items-center gap-2 mt-2 text-gray-600">
              <Clock size={16} />
              <span>{formatTime(timeLeft)}</span>
            </div>
          )}
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {!started ? (
          <div className="bg-white rounded-lg shadow-md p-8 max-w-2xl mx-auto">
            <div className="mb-6">
              <h2 className="text-xl font-semibold mb-4">Instructions</h2>
              <ul className="space-y-2 text-gray-600">
                <li>• Durée de l'examen : {exam.duration} minutes</li>
                <li>• Score minimum requis : {exam.passingScore}%</li>
                <li>• Vous ne pouvez pas mettre l'examen en pause</li>
                <li>• Assurez-vous d'avoir une connexion internet stable</li>
              </ul>
            </div>

            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
              <div className="flex items-center gap-2">
                <AlertCircle className="text-yellow-400" size={20} />
                <p className="text-yellow-700">
                  Une fois commencé, vous ne pourrez pas quitter l'examen
                </p>
              </div>
            </div>

            <button
              onClick={handleStart}
              className="w-full bg-indigo-600 text-white py-3 px-4 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Commencer l'examen
            </button>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md p-8 max-w-3xl mx-auto">
            {/* Exam questions will be implemented here */}
            <p className="text-gray-600">Les questions de l'examen seront affichées ici</p>
          </div>
        )}
      </main>
    </div>
  );
}