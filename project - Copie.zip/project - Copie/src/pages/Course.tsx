import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft, BookOpen } from 'lucide-react';
import { courseContents } from '../data/courseContent';
import { subjectsData } from '../data/subjects';
import { PageContainer } from '../components/layout/PageContainer';
import { PageHeader } from '../components/layout/PageHeader';
import { ContentContainer } from '../components/layout/ContentContainer';
import { AIChatBox } from '../components/AIChatBox';

export function Course() {
  const { subjectId, chapterId } = useParams();
  
  const courseId = subjectId && chapterId ? `${subjectId}-${chapterId}` : '';
  const course = courseContents[courseId];
  const subject = subjectId ? subjectsData[subjectId] : null;
  const chapter = subject?.chapters.find(ch => ch.id === chapterId);

  if (!course || !subject || !chapter) {
    return (
      <PageContainer>
        <ContentContainer>
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900">Cours non trouvé</h2>
            <p className="text-gray-600 mt-2">Le cours demandé n'existe pas.</p>
            <Link
              to={`/subjects/${subjectId}`}
              className="inline-flex items-center gap-2 mt-4 text-indigo-600 hover:text-indigo-700"
            >
              <ChevronLeft size={20} />
              Retour à la matière
            </Link>
          </div>
        </ContentContainer>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title={chapter.title}
        description={chapter.description}
      >
        <Link
          to={`/subjects/${subjectId}`}
          className="inline-flex items-center gap-2 text-indigo-600 hover:text-indigo-700 mt-4"
        >
          <ChevronLeft size={20} />
          Retour à {subject.name}
        </Link>
      </PageHeader>

      <ContentContainer>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {course.sections.map((section) => (
              <div key={section.id} className="mb-8">
                <div className="flex items-center gap-3 mb-4">
                  <BookOpen className="text-indigo-600" size={20} />
                  <h2 className="text-xl font-semibold">{section.title}</h2>
                </div>

                {section.type === 'text' && (
                  <div className="prose max-w-none">
                    {section.content.split('\n\n').map((paragraph, index) => (
                      <p key={index} className="mb-4 text-gray-600">
                        {paragraph}
                      </p>
                    ))}
                  </div>
                )}

                {section.type === 'example' && (
                  <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
                    {section.content.split('\n').map((line, index) => (
                      <p key={index} className="mb-2 last:mb-0">
                        {line}
                      </p>
                    ))}
                  </div>
                )}

                {section.type === 'formula' && (
                  <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded-r-lg font-mono">
                    {section.content.split('\n').map((line, index) => (
                      <p key={index} className="mb-2 last:mb-0">
                        {line}
                      </p>
                    ))}
                  </div>
                )}
              </div>
            ))}

            <div className="mt-8 flex justify-between">
              <Link
                to={`/subjects/${subjectId}`}
                className="inline-flex items-center gap-2 text-gray-600 hover:text-gray-700"
              >
                <ChevronLeft size={20} />
                Retour aux chapitres
              </Link>
              <Link
                to={`/quiz/${subjectId}/${chapterId}`}
                className="bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors"
              >
                Passer au quiz
              </Link>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="sticky top-4">
              <h3 className="text-lg font-semibold mb-4">Assistant IA</h3>
              <AIChatBox
                context={`${subject.name} - ${chapter.title}`}
                placeholder="Posez une question sur le cours..."
              />
            </div>
          </div>
        </div>
      </ContentContainer>
    </PageContainer>
  );
}