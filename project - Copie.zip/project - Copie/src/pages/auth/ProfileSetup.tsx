import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Save, School, BookOpen } from 'lucide-react';
import { grades } from '../../types/auth';
import { subjects } from '../../data/subjects';
import { useAuthStore } from '../../store/authStore';
import UserService from '../../services/userService';

export function ProfileSetup() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [grade, setGrade] = useState('');
  const [school, setSchool] = useState('');
  const [bio, setBio] = useState('');
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      const userService = UserService.getInstance();
      await userService.updateUser(user.uid, {
        displayName: user.displayName || '',
        email: user.email || '',
        grade,
        school,
        bio,
        subjects: selectedSubjects,
        isProfileComplete: true,
        points: 0,
        badges: [],
        progress: {}
      });
      navigate('/');
    } catch (err: any) {
      setError(err.message);
    }
  };

  const toggleSubject = (subjectId: string) => {
    setSelectedSubjects(prev => 
      prev.includes(subjectId)
        ? prev.filter(id => id !== subjectId)
        : [...prev, subjectId]
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 className="text-center text-3xl font-bold text-gray-900">
          Complétez votre profil
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Ces informations nous aideront à personnaliser votre expérience
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          {error && (
            <div className="mb-4 bg-red-50 border-l-4 border-red-400 p-4">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="grade" className="block text-sm font-medium text-gray-700">
                Classe
              </label>
              <select
                id="grade"
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
                required
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
              >
                <option value="">Sélectionnez votre classe</option>
                <optgroup label="Primaire">
                  {grades.filter(g => ['CP', 'CE1', 'CE2', 'CM1', 'CM2'].includes(g)).map((g) => (
                    <option key={g} value={g}>{g}</option>
                  ))}
                </optgroup>
                <optgroup label="Collège">
                  {grades.filter(g => ['6ème', '5ème', '4ème', '3ème'].includes(g)).map((g) => (
                    <option key={g} value={g}>{g}</option>
                  ))}
                </optgroup>
                <optgroup label="Lycée">
                  {grades.filter(g => ['Seconde', 'Première', 'Terminale'].includes(g)).map((g) => (
                    <option key={g} value={g}>{g}</option>
                  ))}
                </optgroup>
              </select>
            </div>

            <div>
              <label htmlFor="school" className="block text-sm font-medium text-gray-700">
                Établissement (optionnel)
              </label>
              <div className="mt-1 relative">
                <input
                  id="school"
                  type="text"
                  value={school}
                  onChange={(e) => setSchool(e.target.value)}
                  className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
                <School className="absolute right-3 top-2.5 text-gray-400" size={20} />
              </div>
            </div>

            <div>
              <label htmlFor="bio" className="block text-sm font-medium text-gray-700">
                Bio (optionnel)
              </label>
              <div className="mt-1">
                <textarea
                  id="bio"
                  rows={3}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Matières préférées
              </label>
              <div className="mt-2 grid grid-cols-2 gap-2">
                {Object.values(subjects).map((subject) => (
                  <button
                    key={subject.id}
                    type="button"
                    onClick={() => toggleSubject(subject.id)}
                    className={`flex items-center p-2 rounded-md ${
                      selectedSubjects.includes(subject.id)
                        ? 'bg-indigo-100 text-indigo-700 border-indigo-200'
                        : 'bg-gray-50 text-gray-700 border-gray-200'
                    } border`}
                  >
                    <BookOpen className="mr-2" size={16} />
                    {subject.name}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <button
                type="submit"
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                <Save className="mr-2" size={20} />
                Enregistrer le profil
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}