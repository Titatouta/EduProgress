import React from 'react';
import { useParams } from 'react-router-dom';
import { GraduationCap, Trophy } from 'lucide-react';
import { ChapterCard } from '../components/ChapterCard';
import { ExamCard } from '../components/ExamCard';
import { subjects } from '../data/subjects';
import ExamService from '../services/examService';
import { PageContainer } from '../components/layout/PageContainer';
import { PageHeader } from '../components/layout/PageHeader';
import { ContentContainer } from '../components/layout/ContentContainer';

export function SubjectDetail() {
  const { subjectId } = useParams();
  const [exams, setExams] = React.useState([]);
  
  const subject = subjectId ? subjects[subjectId] : null;

  React.useEffect(() => {
    const fetchExams = async () => {
      if (subjectId) {
        const examService = ExamService.getInstance();
        const fetchedExams = await examService.getExams(subjectId);
        setExams(fetchedExams);
      }
    };
    fetchExams();
  }, [subjectId]);

  if (!subject) {
    return (
      <PageContainer>
        <ContentContainer>
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900">Matière non trouvée</h2>
            <p className="text-gray-600 mt-2">La matière demandée n'existe pas.</p>
          </div>
        </ContentContainer>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader 
        title={subject.name}
        description={subject.description}
      />
      
      <ContentContainer>
        <div className="space-y-8">
          <section>
            <div className="flex items-center gap-2 mb-6">
              <GraduationCap className="text-indigo-600" size={24} />
              <h2 className="text-xl font-semibold">Chapitres</h2>
            </div>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {subject.chapters.map((chapter) => (
                <ChapterCard 
                  key={chapter.id} 
                  chapter={chapter}
                  subjectId={subject.id}
                />
              ))}
            </div>
          </section>

          <section>
            <div className="flex items-center gap-2 mb-6">
              <Trophy className="text-indigo-600" size={24} />
              <h2 className="text-xl font-semibold">Examens</h2>
            </div>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {exams.map((exam) => (
                <ExamCard key={exam.id} exam={exam} />
              ))}
            </div>
          </section>
        </div>
      </ContentContainer>
    </PageContainer>
  );
}