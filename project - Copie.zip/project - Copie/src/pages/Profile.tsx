import React, { useEffect, useState } from 'react';
import { Settings, LogOut } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import UserService from '../services/userService';
import type { UserProfile } from '../types/auth';

export function Profile() {
  const { user, signOut } = useAuthStore();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      if (user) {
        const userService = UserService.getInstance();
        const userProfile = await userService.getUser(user.uid);
        setProfile(userProfile);
        setLoading(false);
      }
    };
    fetchProfile();
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900">Profil non trouvé</h2>
          <p className="mt-2 text-gray-600">Impossible de charger les informations du profil</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold text-gray-900">Profil</h1>
          <p className="text-gray-600 mt-2">Gérez vos informations personnelles</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-20 h-20 rounded-full overflow-hidden">
              {profile.avatar ? (
                <img 
                  src={profile.avatar} 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-indigo-600 flex items-center justify-center text-white text-2xl font-bold">
                  {profile.displayName?.substring(0, 2).toUpperCase() || 'U'}
                </div>
              )}
            </div>
            <div>
              <h2 className="text-xl font-semibold">{profile.displayName}</h2>
              <p className="text-gray-600">Niveau: {profile.grade}</p>
              {profile.school && (
                <p className="text-gray-600 text-sm">{profile.school}</p>
              )}
            </div>
          </div>

          {profile.bio && (
            <div className="mb-6">
              <h3 className="font-medium mb-2">Bio</h3>
              <p className="text-gray-600">{profile.bio}</p>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <h3 className="font-medium mb-2">Points totaux</h3>
              <p className="text-2xl font-bold text-indigo-600">{profile.points || 0}</p>
            </div>
            <div>
              <h3 className="font-medium mb-2">Matières préférées</h3>
              <div className="flex flex-wrap gap-2">
                {profile.subjects?.map((subject) => (
                  <span
                    key={subject}
                    className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm"
                  >
                    {subject}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <Link
            to="/settings"
            className="w-full flex items-center gap-3 bg-white p-4 rounded-lg shadow-md hover:bg-gray-50"
          >
            <Settings size={20} />
            <span>Paramètres</span>
          </Link>
          <button 
            onClick={() => signOut()}
            className="w-full flex items-center gap-3 bg-white p-4 rounded-lg shadow-md hover:bg-gray-50 text-red-600"
          >
            <LogOut size={20} />
            <span>Déconnexion</span>
          </button>
        </div>
      </main>
    </div>
  );
}