import React from 'react';
import { Rocket, Trophy, Target } from 'lucide-react';

export function Home() {
  return (
    <div className="min-h-screen bg-gray-50 pb-16">
      <header className="bg-indigo-600 text-white py-8 px-4">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold mb-2">Bienvenue sur EduSuccess</h1>
          <p className="text-indigo-100">Votre parcours vers la réussite commence ici</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <section className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <Rocket className="text-indigo-600 mb-4" size={32} />
            <h2 className="text-xl font-semibold mb-2">Progression Personnalisée</h2>
            <p className="text-gray-600">Suivez votre progression et adaptez votre apprentissage</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <Trophy className="text-indigo-600 mb-4" size={32} />
            <h2 className="text-xl font-semibold mb-2">Gagnez des Récompenses</h2>
            <p className="text-gray-600">Débloquez des badges et montez en niveau</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <Target className="text-indigo-600 mb-4" size={32} />
            <h2 className="text-xl font-semibold mb-2">Objectifs Quotidiens</h2>
            <p className="text-gray-600">Relevez des défis pour progresser chaque jour</p>
          </div>
        </section>

        <section className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">Votre Progression</h2>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Mathématiques</span>
                <span className="text-sm text-gray-500">75%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-indigo-600 rounded-full h-2" style={{ width: '75%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Français</span>
                <span className="text-sm text-gray-500">60%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-indigo-600 rounded-full h-2" style={{ width: '60%' }} />
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}