export interface Subject {
  id: string;
  name: string;
  level: 'primary' | 'middle' | 'high';
  icon: string;
}

export interface User {
  id: string;
  name: string;
  level: string;
  progress: {
    [subjectId: string]: number;
  };
  badges: string[];
  points: number;
}

export interface Quiz {
  id: string;
  subjectId: string;
  title: string;
  questions: Question[];
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}