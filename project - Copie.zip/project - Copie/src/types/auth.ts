export interface UserProfile {
  id: string;
  email: string;
  displayName: string;
  grade: string;
  school?: string;
  avatar?: string;
  bio?: string;
  subjects: string[];
  isProfileComplete: boolean;
}

export interface ProfileFormData {
  displayName: string;
  grade: string;
  school?: string;
  bio?: string;
  subjects: string[];
}

export const grades = [
  // Primaire
  'CP',
  'CE1',
  'CE2',
  'CM1',
  'CM2',
  // Collège
  '6ème',
  '5ème',
  '4ème',
  '3ème',
  // Lycée
  'Seconde',
  'Première',
  'Terminale'
];

export const gradeCategories = {
  primary: ['CP', 'CE1', 'CE2', 'CM1', 'CM2'],
  middle: ['6ème', '5ème', '4ème', '3ème'],
  high: ['Seconde', 'Première', 'Terminale']
};