export interface Grade {
  id: string;
  name: string;
  category: 'primary' | 'middle' | 'high';
}

export const grades: Grade[] = [
  // Primaire
  { id: 'cp', name: 'CP', category: 'primary' },
  { id: 'ce1', name: 'CE1', category: 'primary' },
  { id: 'ce2', name: 'CE2', category: 'primary' },
  { id: 'cm1', name: 'CM1', category: 'primary' },
  { id: 'cm2', name: 'CM2', category: 'primary' },
  // Collège
  { id: '6e', name: '6e', category: 'middle' },
  { id: '5e', name: '5e', category: 'middle' },
  { id: '4e', name: '4e', category: 'middle' },
  { id: '3e', name: '3e', category: 'middle' },
  // Lycée
  { id: '2nd', name: 'Seconde', category: 'high' },
  { id: '1ere', name: 'Première', category: 'high' },
  { id: 'tle', name: 'Terminale', category: 'high' },
];

export const gradeCategories = {
  primary: 'Primaire',
  middle: 'Collège',
  high: 'Lycée'
};