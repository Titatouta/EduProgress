import axios from 'axios';

const COMMONLIT_API_URL = 'https://api.commonlit.org/v1';

export interface CommonLitText {
  id: string;
  title: string;
  author: string;
  description: string;
  content: string;
  readingLevel: string;
  subjects: string[];
}

export interface CommonLitQuestion {
  id: string;
  textId: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

class ApiService {
  private static instance: ApiService;
  
  private constructor() {}

  public static getInstance(): ApiService {
    if (!ApiService.instance) {
      ApiService.instance = new ApiService();
    }
    return ApiService.instance;
  }

  async getTexts(level: string): Promise<CommonLitText[]> {
    try {
      const response = await axios.get(`${COMMONLIT_API_URL}/texts`, {
        params: { reading_level: level }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching texts:', error);
      return [];
    }
  }

  async getQuestions(textId: string): Promise<CommonLitQuestion[]> {
    try {
      const response = await axios.get(`${COMMONLIT_API_URL}/texts/${textId}/questions`);
      return response.data;
    } catch (error) {
      console.error('Error fetching questions:', error);
      return [];
    }
  }
}

export default ApiService;