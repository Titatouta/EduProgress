import { 
  doc,
  setDoc,
  getDoc,
  updateDoc,
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '../config/firebase';
import type { User } from '../types';

class UserService {
  private static instance: UserService;
  private collection = 'users';

  private constructor() {}

  public static getInstance(): UserService {
    if (!UserService.instance) {
      UserService.instance = new UserService();
    }
    return UserService.instance;
  }

  async createUser(userId: string, userData: Partial<User>): Promise<void> {
    const userRef = doc(db, this.collection, userId);
    await setDoc(userRef, {
      ...userData,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  }

  async getUser(userId: string): Promise<User | null> {
    const userRef = doc(db, this.collection, userId);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      return null;
    }

    return userDoc.data() as User;
  }

  async updateUser(userId: string, userData: Partial<User>): Promise<void> {
    const userRef = doc(db, this.collection, userId);
    await updateDoc(userRef, {
      ...userData,
      updatedAt: serverTimestamp(),
    });
  }

  async updateProgress(userId: string, subjectId: string, progress: number): Promise<void> {
    const userRef = doc(db, this.collection, userId);
    await updateDoc(userRef, {
      [`progress.${subjectId}`]: progress,
      updatedAt: serverTimestamp(),
    });
  }

  async addPoints(userId: string, points: number): Promise<void> {
    const userRef = doc(db, this.collection, userId);
    const userDoc = await getDoc(userRef);
    
    if (userDoc.exists()) {
      const currentPoints = userDoc.data().points || 0;
      await updateDoc(userRef, {
        points: currentPoints + points,
        updatedAt: serverTimestamp(),
      });
    }
  }
}

export default UserService;