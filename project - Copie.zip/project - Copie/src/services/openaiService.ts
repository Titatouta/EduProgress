import OpenAI from 'openai';

interface AIResponse {
  content: string;
  error?: {
    type: string;
    message: string;
  };
}

class OpenAIService {
  private static instance: OpenAIService;
  private openai: OpenAI;
  private fallbackResponses: Record<string, string[]>;

  private constructor() {
    this.openai = new OpenAI({
      apiKey: import.meta.env.VITE_OPENAI_API_KEY,
      dangerouslyAllowBrowser: true
    });

    // Réponses de secours par matière
    this.fallbackResponses = {
      math: [
        "Je peux vous aider avec les concepts mathématiques de base comme l'algèbre, la géométrie et l'arithmétique.",
        "N'hésitez pas à me poser des questions sur les formules et les théorèmes.",
        "Je peux vous guider dans la résolution de problèmes mathématiques étape par étape."
      ],
      french: [
        "Je peux vous aider avec la grammaire, la conjugaison et l'analyse de textes.",
        "N'hésitez pas à me poser des questions sur les règles de la langue française.",
        "Je peux vous aider à améliorer votre expression écrite."
      ],
      default: [
        "Je suis là pour vous aider dans votre apprentissage.",
        "N'hésitez pas à me poser des questions sur le sujet qui vous intéresse.",
        "Je peux vous expliquer les concepts de manière simple et claire."
      ]
    };
  }

  public static getInstance(): OpenAIService {
    if (!OpenAIService.instance) {
      OpenAIService.instance = new OpenAIService();
    }
    return OpenAIService.instance;
  }

  private getFallbackResponse(context?: string): string {
    const subject = context?.toLowerCase().split(' ')[0] || 'default';
    const responses = this.fallbackResponses[subject] || this.fallbackResponses.default;
    return responses[Math.floor(Math.random() * responses.length)];
  }

  async generateResponse(
    messages: { role: 'system' | 'user' | 'assistant'; content: string }[]
  ): Promise<AIResponse> {
    try {
      const completion = await this.openai.chat.completions.create({
        messages: messages,
        model: 'gpt-3.5-turbo',
        temperature: 0.7,
        max_tokens: 500
      });

      return {
        content: completion.choices[0].message.content || ''
      };
    } catch (error: any) {
      console.error('Error generating response:', error);

      // Déterminer le contexte à partir des messages système
      const systemMessage = messages.find(msg => msg.role === 'system');
      const context = systemMessage?.content.match(/expert en (.*?)\./)?.[1];

      // Erreur de quota
      if (error?.error?.code === 'insufficient_quota') {
        return {
          content: this.getFallbackResponse(context),
          error: {
            type: 'quota_exceeded',
            message: "Le service est temporairement indisponible. Nous utilisons une réponse de secours."
          }
        };
      }

      // Autres erreurs
      return {
        content: "Je suis désolé, je ne peux pas répondre pour le moment. Veuillez réessayer plus tard.",
        error: {
          type: 'general_error',
          message: error.message || "Une erreur s'est produite"
        }
      };
    }
  }
}

export default OpenAIService;