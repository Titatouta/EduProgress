import type { Quiz } from '../types';

export interface Exam extends Quiz {
  duration: number; // in minutes
  passingScore: number;
  difficulty: 'easy' | 'medium' | 'hard';
  category: string;
}

class ExamService {
  private static instance: ExamService;
  
  private constructor() {}

  public static getInstance(): ExamService {
    if (!ExamService.instance) {
      ExamService.instance = new ExamService();
    }
    return ExamService.instance;
  }

  async getExams(subjectId: string): Promise<Exam[]> {
    // Simulated data - in a real app, this would fetch from an API
    return [
      {
        id: 'exam1',
        subjectId,
        title: 'Examen de fin de chapitre - Algèbre',
        questions: [],
        duration: 60,
        passingScore: 70,
        difficulty: 'medium',
        category: 'algebra'
      },
      {
        id: 'exam2',
        subjectId,
        title: 'Examen final - Géométrie',
        questions: [],
        duration: 90,
        passingScore: 75,
        difficulty: 'hard',
        category: 'geometry'
      }
    ];
  }
}

export default ExamService;