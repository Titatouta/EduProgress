import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import { Navigation } from './components/Navigation';
import { Home } from './pages/Home';
import { Login } from './pages/auth/Login';
import { Register } from './pages/auth/Register';
import { ProfileSetup } from './pages/auth/ProfileSetup';
import { Settings } from './pages/Settings';
import { Course } from './pages/Course';
import { Quiz } from './pages/Quiz';
import { Exam } from './pages/Exam';
import { Subjects } from './pages/Subjects';
import { SubjectDetail } from './pages/SubjectDetail';
import { Achievements } from './pages/Achievements';
import { Profile } from './pages/Profile';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuthStore();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  return <>{children}</>;
}

export function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route 
            path="/profile/setup" 
            element={
              <PrivateRoute>
                <ProfileSetup />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/settings" 
            element={
              <PrivateRoute>
                <Settings />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/" 
            element={
              <PrivateRoute>
                <Home />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/subjects" 
            element={
              <PrivateRoute>
                <Subjects />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/subjects/:subjectId" 
            element={
              <PrivateRoute>
                <SubjectDetail />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/course/:subjectId/:chapterId" 
            element={
              <PrivateRoute>
                <Course />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/quiz/:subjectId/:chapterId" 
            element={
              <PrivateRoute>
                <Quiz />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/exam/:examId" 
            element={
              <PrivateRoute>
                <Exam />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/achievements" 
            element={
              <PrivateRoute>
                <Achievements />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/profile" 
            element={
              <PrivateRoute>
                <Profile />
              </PrivateRoute>
            } 
          />
        </Routes>
        <Navigation />
      </div>
    </Router>
  );
}