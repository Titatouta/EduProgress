import { create } from 'zustand';
import type { User } from 'firebase/auth';
import AuthService from '../services/authService';
import UserService from '../services/userService';

interface AuthState {
  user: User | null;
  loading: boolean;
  error: string | null;
  signUp: (email: string, password: string, displayName: string) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  loading: true,
  error: null,

  signUp: async (email: string, password: string, displayName: string) => {
    try {
      set({ loading: true, error: null });
      const authService = AuthService.getInstance();
      const userService = UserService.getInstance();
      
      const user = await authService.signUp(email, password, displayName);
      await userService.createUser(user.uid, {
        id: user.uid,
        name: displayName,
        email: user.email || '',
        level: 'middle',
        progress: {},
        badges: [],
        points: 0
      });
      
      set({ user, loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
    }
  },

  signIn: async (email: string, password: string) => {
    try {
      set({ loading: true, error: null });
      const authService = AuthService.getInstance();
      const user = await authService.signIn(email, password);
      set({ user, loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
    }
  },

  signOut: async () => {
    try {
      set({ loading: true, error: null });
      const authService = AuthService.getInstance();
      await authService.signOut();
      set({ user: null, loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
    }
  },

  clearError: () => set({ error: null })
}));

// Initialize auth state listener
AuthService.getInstance().onAuthStateChange((user) => {
  useAuthStore.setState({ user, loading: false });
});