import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Grade, grades } from '../types/grades';

interface LevelState {
  currentLevel: Grade;
  setLevel: (level: Grade) => void;
}

export const useLevelStore = create<LevelState>()(
  persist(
    (set) => ({
      currentLevel: grades.find(g => g.id === '3e')!,
      setLevel: (level: Grade) => set({ currentLevel: level }),
    }),
    {
      name: 'level-storage',
    }
  )
);