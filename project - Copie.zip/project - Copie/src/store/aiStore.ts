import { create } from 'zustand';
import OpenAIService from '../services/openaiService';

interface AIState {
  messages: Message[];
  isLoading: boolean;
  error: string | null;
  sendMessage: (content: string, context?: string) => Promise<void>;
  clearMessages: () => void;
  clearError: () => void;
}

interface Message {
  role: 'system' | 'user' | 'assistant';
  content: string;
  error?: {
    type: string;
    message: string;
  };
}

export const useAIStore = create<AIState>((set, get) => ({
  messages: [],
  isLoading: false,
  error: null,
  
  sendMessage: async (content: string, context?: string) => {
    const { messages } = get();
    set({ isLoading: true, error: null });

    const newMessages = [...messages];
    
    // Add system message if it's the first message
    if (messages.length === 0 && context) {
      newMessages.unshift({
        role: 'system',
        content: `Tu es un assistant pédagogique expert en ${context}. Aide l'élève à comprendre les concepts et réponds à ses questions de manière claire et adaptée à son niveau.`
      });
    }

    // Add user message
    newMessages.push({ role: 'user', content });
    set({ messages: newMessages });

    try {
      const openaiService = OpenAIService.getInstance();
      const response = await openaiService.generateResponse(newMessages);
      
      set(state => ({
        messages: [...state.messages, {
          role: 'assistant',
          content: response.content,
          error: response.error
        }],
        error: response.error?.message || null,
        isLoading: false
      }));
    } catch (error) {
      set(state => ({
        messages: [...state.messages, {
          role: 'assistant',
          content: "Désolé, je n'ai pas pu générer une réponse. Veuillez réessayer."
        }],
        error: "Une erreur inattendue s'est produite. Veuillez réessayer.",
        isLoading: false
      }));
    }
  },

  clearMessages: () => set({ messages: [], error: null }),
  clearError: () => set({ error: null })
}));