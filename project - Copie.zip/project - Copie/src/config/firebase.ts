import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getAnalytics } from 'firebase/analytics';

const firebaseConfig = {
  apiKey: "AIzaSyD0q4AjTtDEoKOSXQeRnJHsbcDiUUXN00U",
  authDomain: "eduapp-8a2fe.firebaseapp.com",
  projectId: "eduapp-8a2fe",
  storageBucket: "eduapp-8a2fe.firebasestorage.app",
  messagingSenderId: "727874325220",
  appId: "1:727874325220:web:4be89cccc6f08613137af1",
  measurementId: "G-27CZY714XB"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const analytics = getAnalytics(app);

export default app;